BME WEBSITE — QUICK START

1. Open index.html in a browser to preview the website.
2. Replace the Instagram link with your real BME Instagram URL.
3. Replace yourbusiness@email.com with your real business email.
4. When ready to publish, upload index.html to a static website host.

The site is responsive and uses plain HTML/CSS, so you can edit it without a framework.
